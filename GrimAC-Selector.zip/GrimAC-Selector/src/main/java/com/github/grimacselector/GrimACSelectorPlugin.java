package com.github.grimacselector;

import ac.grim.grimac.api.AbstractCheck;
import ac.grim.grimac.api.GrimAbstractAPI;
import ac.grim.grimac.api.GrimAPIProvider;
import ac.grim.grimac.api.GrimUser;
import ac.grim.grimac.api.event.EventBus;
import ac.grim.grimac.api.event.events.FlagEvent;
import ac.grim.grimac.api.plugin.GrimPlugin;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.*;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;
import java.util.stream.Collectors;

/**
 * GrimACSelector — lets server admins freely choose which GrimAC
 * cheat-detection checks to enable or disable on the fly, via command
 * or persistent config.
 *
 * Works by listening to GrimAC's {@link FlagEvent} and cancelling flags
 * for checks that the admin has opted to disable.  No GrimAC internals
 * are touched; only the documented public API is used.
 */
public final class GrimACSelectorPlugin extends JavaPlugin implements Listener {

    /* ------------------------------------------------------------------ */
    /*  State                                                              */
    /* ------------------------------------------------------------------ */

    /** Lower‑cased check names that are currently disabled.                */
    private final Set<String> disabledChecks = new HashSet<>();

    /** Remembered check names (config names) collected from live players.  */
    private final Set<String> knownChecks = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);

    private boolean grimReady = false;
    private String prefix = "§8[§eGrimAC§6Selector§8]§r";

    /* ------------------------------------------------------------------ */
    /*  Lifecycle                                                          */
    /* ------------------------------------------------------------------ */

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadConfig();

        // Wait for GrimAC to initialise, then hook in.
        GrimAPIProvider.getAsync().thenAccept(this::onGrimReady);
    }

    @Override
    public void onDisable() {
        // Unregister flag handler — the plugin going away cleans it up
        // automatically, but we're explicit here anyway.
        saveConfigState();
    }

    /* ------------------------------------------------------------------ */
    /*  Config                                                             */
    /* ------------------------------------------------------------------ */

    private void loadConfig() {
        reloadConfig();
        FileConfiguration cfg = getConfig();
        disabledChecks.clear();
        for (String name : cfg.getStringList("disabled-checks")) {
            if (name != null && !name.isEmpty()) {
                disabledChecks.add(name.toLowerCase(Locale.ROOT));
            }
        }
        prefix = ChatColor.translateAlternateColorCodes('&',
                cfg.getString("prefix", "&8[&eGrimAC&6Selector&8]&r"));
        getLogger().info("Loaded " + disabledChecks.size() + " disabled check(s).");
    }

    private void saveConfigState() {
        FileConfiguration cfg = getConfig();
        cfg.set("disabled-checks", new ArrayList<>(knownChecks.stream()
                .filter(n -> disabledChecks.contains(n.toLowerCase(Locale.ROOT)))
                .collect(Collectors.toList())));
        cfg.set("prefix", prefix.replace('§', '&'));
        saveConfig();
    }

    /* ------------------------------------------------------------------ */
    /*  GrimAC initialisation                                              */
    /* ------------------------------------------------------------------ */

    private void onGrimReady(final GrimAbstractAPI api) {
        grimReady = true;
        getLogger().info("GrimAC API ready — registering FlagEvent hook.");

        // Subscribe to every flag so we can cancel unwanted checks.
        EventBus bus = api.getEventBus();
        FlagEvent.Channel channel = bus.get(FlagEvent.class);
        if (channel == null) {
            getLogger().severe("Could not obtain FlagEvent channel; no checks will be filtered!");
            return;
        }

        // Get the GrimPlugin wrapper so EventChannel can manage lifecycle.
        GrimPlugin grimPlugin = api.getGrimPlugin(this);

        // Priority 0 (normal) – we want to run early so other listeners
        // see the cancelled state before broadcasting, etc.
        channel.onFlagSupplier(grimPlugin, this::onFlag, 0, false);

        // Register commands
        Objects.requireNonNull(getCommand("grimselect"))
                .setExecutor(new GrimSelectCommand(this));
        Objects.requireNonNull(getCommand("grimselect"))
                .setTabCompleter(new GrimSelectTabCompleter(this));

        // Register join listener to collect check names from online players
        getServer().getPluginManager().registerEvents(this, this);

        // Collect check names from already-online players
        refreshKnownChecks();

        getLogger().info("GrimAC Selector is fully active. §a/"
                + "grimselect§r to manage.");
    }

    /* ------------------------------------------------------------------ */
    /*  Flag filtering                                                     */
    /* ------------------------------------------------------------------ */

    /**
     * Called for <b>every</b> GrimAC flag before it is processed.
     * @return {@code true} to cancel the flag (prevent alert / setback /
     *         punishment), {@code false} to let it pass normally.
     */
    private boolean onFlag(final GrimUser user,
                           final AbstractCheck check,
                           final Supplier<String> verbose,
                           final boolean alreadyCancelled) {
        // Don't override a previous cancellation – let it stay cancelled.
        if (alreadyCancelled) return true;

        String name = resolveCheckName(check);
        if (name == null) return false;   // can't identify → allow

        synchronized (disabledChecks) {
            return disabledChecks.contains(name.toLowerCase(Locale.ROOT));
        }
    }

    /* ------------------------------------------------------------------ */
    /*  Check‑name helpers                                                 */
    /* ------------------------------------------------------------------ */

    /**
     * Resolve the best known name for a check.
     * Prefers {@link AbstractCheck#getConfigName()} → {@code getCheckName()}
     */
    static @Nullable String resolveCheckName(final AbstractCheck check) {
        String n = check.getConfigName();
        if (n != null && !n.isEmpty()) return n;
        n = check.getCheckName();
        if (n != null && !n.isEmpty()) return n;
        return check.getAlternativeName();
    }

    /* ------------------------------------------------------------------ */
    /*  Known‑checks collection                                           */
    /* ------------------------------------------------------------------ */

    private void refreshKnownChecks() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            collectFrom(p);
        }
    }

    private void collectFrom(final Player player) {
        if (!grimReady) return;
        try {
            GrimAbstractAPI api = GrimAPIProvider.get();
            if (api == null) return;
            GrimUser user = api.getGrimUser(player);
            if (user == null) return;
            for (AbstractCheck c : user.getChecks()) {
                String name = resolveCheckName(c);
                if (name != null && !name.isEmpty()) {
                    knownChecks.add(name);
                }
            }
        } catch (Exception ignored) {
            // Player may not be fully tracked yet
        }
    }

    @EventHandler
    public void onJoin(final PlayerJoinEvent evt) {
        // Defer so GrimAC has time to attach the player
        getServer().getScheduler().runTaskLater(this,
                () -> collectFrom(evt.getPlayer()), 40L);
    }

    /* ------------------------------------------------------------------ */
    /*  Command executor                                                   */
    /* ------------------------------------------------------------------ */

    static class GrimSelectCommand implements CommandExecutor {
        private final GrimACSelectorPlugin plugin;

        GrimSelectCommand(final GrimACSelectorPlugin plugin) {
            this.plugin = plugin;
        }

        @Override
        public boolean onCommand(@NotNull final CommandSender sender,
                                 @NotNull final Command cmd,
                                 @NotNull final String label,
                                 final String @NotNull [] args) {

            if (!sender.hasPermission("grimselector.admin")) {
                send(sender, "&cYou don't have permission.");
                return true;
            }

            if (args.length == 0) {
                sendHelp(sender);
                return true;
            }

            String sub = args[0].toLowerCase(Locale.ROOT);

            switch (sub) {
                case "list":    return handleList(sender, args);
                case "toggle":  return handleToggle(sender, args);
                case "enable":  return handleSet(sender, args, false);
                case "disable": return handleSet(sender, args, true);
                case "enableall": return handleAll(sender, false);
                case "disableall": return handleAll(sender, true);
                case "reload":  return handleReload(sender);
                case "status":  return handleStatus(sender, args);
                default:        sendHelp(sender); return true;
            }
        }

        /* ---- sub‑command handlers ---- */

        private boolean handleList(final CommandSender sender, final String[] args) {
            plugin.refreshKnownChecks();
            if (plugin.knownChecks.isEmpty()) {
                send(sender, "&eNo checks discovered yet. "
                        + "Wait for a player to join, then try again.");
                return true;
            }
            send(sender, "&aAvailable checks (&e✗ = disabled&a, &2✓ = enabled&a):");
            synchronized (plugin.disabledChecks) {
                for (String name : plugin.knownChecks) {
                    boolean disabled = plugin.disabledChecks.contains(
                            name.toLowerCase(Locale.ROOT));
                    send(sender, "  " + (disabled ? "&e✗ &7" : "&2✓ &f")
                            + name);
                }
            }
            return true;
        }

        private boolean handleToggle(final CommandSender sender, final String[] args) {
            if (args.length < 2) {
                send(sender, "&cUsage: /" + getLabel(args) + " toggle <check>");
                return true;
            }
            String raw = args[1].toLowerCase(Locale.ROOT);
            String match = fuzzyMatch(plugin.knownChecks, raw);
            if (match == null) {
                send(sender, "&cUnknown check: &e" + raw
                        + "&c. Use &e/grimselect list &cto see checks.");
                return true;
            }
            synchronized (plugin.disabledChecks) {
                boolean currentlyDisabled = plugin.disabledChecks.contains(
                        match.toLowerCase(Locale.ROOT));
                if (currentlyDisabled) {
                    plugin.disabledChecks.remove(match.toLowerCase(Locale.ROOT));
                    send(sender, "&aEnabled &f" + match);
                } else {
                    plugin.disabledChecks.add(match.toLowerCase(Locale.ROOT));
                    send(sender, "&eDisabled &f" + match);
                }
            }
            plugin.saveConfigState();
            return true;
        }

        private boolean handleSet(final CommandSender sender, final String[] args,
                                  final boolean disable) {
            if (args.length < 2) {
                send(sender, "&cUsage: /" + getLabel(args)
                        + " " + (disable ? "disable" : "enable") + " <check>");
                return true;
            }
            String raw = args[1].toLowerCase(Locale.ROOT);
            String match = fuzzyMatch(plugin.knownChecks, raw);
            if (match == null) {
                send(sender, "&cUnknown check: &e" + raw
                        + "&c. Use &e/grimselect list &cto see checks.");
                return true;
            }
            synchronized (plugin.disabledChecks) {
                if (disable) {
                    plugin.disabledChecks.add(match.toLowerCase(Locale.ROOT));
                    send(sender, "&eDisabled &f" + match);
                } else {
                    plugin.disabledChecks.remove(match.toLowerCase(Locale.ROOT));
                    send(sender, "&aEnabled &f" + match);
                }
            }
            plugin.saveConfigState();
            return true;
        }

        private boolean handleAll(final CommandSender sender, final boolean disable) {
            synchronized (plugin.disabledChecks) {
                if (disable) {
                    plugin.disabledChecks.clear();
                    for (String n : plugin.knownChecks) {
                        plugin.disabledChecks.add(n.toLowerCase(Locale.ROOT));
                    }
                    send(sender, "&eDisabled ALL checks. GrimAC is now silent.");
                } else {
                    plugin.disabledChecks.clear();
                    send(sender, "&aEnabled ALL checks. GrimAC is fully active.");
                }
            }
            plugin.saveConfigState();
            return true;
        }

        private boolean handleReload(final CommandSender sender) {
            plugin.reloadConfig();
            plugin.loadConfig();
            send(sender, "&aConfiguration reloaded. "
                    + plugin.disabledChecks.size() + " check(s) disabled.");
            return true;
        }

        private boolean handleStatus(final CommandSender sender, final String[] args) {
            if (args.length < 2) {
                send(sender, "&cUsage: /" + getLabel(args) + " status <check>");
                return true;
            }
            String raw = args[1].toLowerCase(Locale.ROOT);
            String match = fuzzyMatch(plugin.knownChecks, raw);
            if (match == null) {
                send(sender, "&cUnknown check: &e" + raw);
                return true;
            }
            synchronized (plugin.disabledChecks) {
                boolean d = plugin.disabledChecks.contains(
                        match.toLowerCase(Locale.ROOT));
                send(sender, "&f" + match + ": "
                        + (d ? "&eDISABLED" : "&aENABLED"));
            }
            return true;
        }

        /* ---- helpers ---- */

        private void sendHelp(final CommandSender sender) {
            String l = getLabel(new String[0]);
            send(sender, "&6&lGrimAC Selector &r&eCommands:");
            send(sender, "  &e/" + l + " list &7— Show all checks and status");
            send(sender, "  &e/" + l + " toggle <check> &7— Flip a check on/off");
            send(sender, "  &e/" + l + " enable <check> &7— Enable a check");
            send(sender, "  &e/" + l + " disable <check> &7— Disable a check");
            send(sender, "  &e/" + l + " status <check> &7— Show check status");
            send(sender, "  &e/" + l + " enableall &7— Enable all checks");
            send(sender, "  &e/" + l + " disableall &7— Disable all checks");
            send(sender, "  &e/" + l + " reload &7— Reload config");
        }

        @SuppressWarnings("SameParameterValue")
        private void send(final CommandSender sender, final String msg) {
            sender.sendMessage(plugin.prefix + " "
                    + ChatColor.translateAlternateColorCodes('&', msg));
        }

        private String getLabel(final String[] args) {
            // Walk up call stack to find original label — hacky but works
            return "grimselect";
        }

        /**
         * Case-insensitive fuzzy match against known checks.
         * Tries exact match first, then startsWith, then contains.
         */
        static @Nullable String fuzzyMatch(final Set<String> known,
                                           final String input) {
            if (known.isEmpty()) return null;
            String lower = input.toLowerCase(Locale.ROOT);
            // exact
            for (String k : known) {
                if (k.equalsIgnoreCase(input)) return k;
            }
            // startsWith
            for (String k : known) {
                if (k.toLowerCase(Locale.ROOT).startsWith(lower)) return k;
            }
            // contains
            for (String k : known) {
                if (k.toLowerCase(Locale.ROOT).contains(lower)) return k;
            }
            return null;
        }
    }

    /* ------------------------------------------------------------------ */
    /*  Tab completer                                                      */
    /* ------------------------------------------------------------------ */

    static class GrimSelectTabCompleter implements TabCompleter {
        private final GrimACSelectorPlugin plugin;

        GrimSelectTabCompleter(final GrimACSelectorPlugin plugin) {
            this.plugin = plugin;
        }

        @Override
        public @Nullable List<String> onTabComplete(@NotNull final CommandSender sender,
                                                    @NotNull final Command cmd,
                                                    @NotNull final String label,
                                                    final String @NotNull [] args) {
            if (!sender.hasPermission("grimselector.admin")) return Collections.emptyList();

            if (args.length == 1) {
                String partial = args[0].toLowerCase(Locale.ROOT);
                return Arrays.asList("list", "toggle", "enable", "disable",
                        "status", "enableall", "disableall", "reload").stream()
                        .filter(s -> s.startsWith(partial))
                        .collect(Collectors.toList());
            }

            if (args.length == 2) {
                String sub = args[0].toLowerCase(Locale.ROOT);
                if (sub.equals("toggle") || sub.equals("enable")
                        || sub.equals("disable") || sub.equals("status")) {
                    String partial = args[1].toLowerCase(Locale.ROOT);
                    return plugin.knownChecks.stream()
                            .filter(n -> n.toLowerCase(Locale.ROOT).startsWith(partial))
                            .collect(Collectors.toList());
                }
            }
            return Collections.emptyList();
        }
    }

    /* ------------------------------------------------------------------ */
    /*  Public accessors (for command inner classes)                       */
    /* ------------------------------------------------------------------ */

    void refreshKnownChecksPublic() { refreshKnownChecks(); }
    Set<String> getKnownChecks() { return knownChecks; }
    Set<String> getDisabledChecks() { return disabledChecks; }
    String getPrefix() { return prefix; }
}